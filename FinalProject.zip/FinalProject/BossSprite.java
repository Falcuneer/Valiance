import javafx.application.Application;
import javafx.stage.*;
import javafx.event.*;
import javafx.scene.*;
import javafx.scene.text.*;
import javafx.scene.input.*;
import javafx.scene.shape.*;
import javafx.scene.paint.*;
import javafx.scene.image.*;
import javafx.animation.*;

public class BossSprite extends Group{

  private ImagePattern imgPattern;
	private Rectangle bosssprite;
  private int health;

  public BossSprite(int h){

    health = h;

    bosssprite = new Rectangle(300, 400);

    Image Boss = new Image("file:levi.png");
    imgPattern = new ImagePattern(Boss);
    bosssprite.setFill(imgPattern);

    this.getChildren().add(bosssprite);
  }

    public void gainHealth(double typeOfAttack){
        if (typeOfAttack == 3 && health < 20){
          health = health + 2;
          System.out.println("Boss's health: " + health);
        }
    }
    public void takeDamageFromSwordswoman(){
        health = health - 5;
        System.out.println("-5 damage " + health);
    }
    public void takeDamageFromHammerGuy(){
      health = health - 3;
    }
    public void takeDamageFromArcher(){
      health = health - 5;
    }
    public void takeDamageFromHealer(){
      health = health - 2;
    }
    public boolean shinay(){
      if(health <= 0){
        bosssprite.setTranslateX(1000);
        return true;
      }
      else {
        return false;
      }
    }
}
