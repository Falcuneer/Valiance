import javafx.application.Application;
import javafx.stage.*;
import javafx.event.*;
import javafx.scene.*;
import javafx.scene.text.*;
import javafx.scene.input.*;
import javafx.scene.shape.*;
import javafx.scene.paint.*;
import javafx.scene.image.*;
import javafx.animation.*;

public class MinionSprite extends Group{

  private ImagePattern imgPattern;
	private Rectangle minionsprite;
  private int health;

  public MinionSprite(int h){

    health = h;

    minionsprite = new Rectangle(125, 125);

    Image Minion  = new Image("file:minion.png");
    imgPattern = new ImagePattern(Minion);
    minionsprite.setFill(imgPattern);

    this.getChildren().add(minionsprite);
  }

  public void takeDamageFromSwordswoman(){
      health = health - 5;
    }
  public void takeDamageFromHammerGuy(){
    health = health - 5;
  }
  public void takeDamageFromArcher(){
    health = health - 5;
  }
  public void takeDamageFromHealer(){
    health = health - 2;
  }
  public boolean shinay(){
    if(health <= 0){
      minionsprite.setTranslateX(1000);
      return true;
    }
    else {
      return false;
    }
  }
}
