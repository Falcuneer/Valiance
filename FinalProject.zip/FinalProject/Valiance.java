/*

Rectangle sky = new Rectangle(0, 0, 800, 300); //x, y, width, height
Line line = new Line(50, 50, 100, 100); //startX, startY, endX, endY
Circle c = new Circle(100, 100, 25); //centerX, centerY, radius
Ellipse e = new Ellipse(100, 100, 25, 50); //centerX, centerY, radiusX, radiusY
Polygon p = new Polygon(0, 0, 100, 0, 50, 50); //x1, y1, x2, y2, x3, y3, etc.

*/

//Notes to Self:
	//Don't forget that if you change the name of a method
	//Or anything else, always translate it where a change
	//Would occur.
	//Might need to change the damage to one damage type.
	//The only thing that differs is the sprite.
	//This would make things easier and less complicated.
	//So then, the game would just be aesthetic (due to time)
	//You can always change this later so don't fret
//Things to Work on in the Future (If you want):
	//How to display health or a health bar
	//Randomizer problem
	//Make a chevron to indicate which enemy you are selecting
	//Health bar or display text saying how much damage is taken

import javafx.stage.*;
import javafx.event.*;
import javafx.scene.*;
import javafx.scene.text.*;
import javafx.scene.input.*;
import javafx.scene.shape.*;
import javafx.scene.paint.*;
import javafx.scene.image.*;
import javafx.scene.paint.*;
import javafx.animation.*;
import javafx.util.*;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import java.net.URL;
import javafx.application.Application;
import java.util.Scanner;

public class Valiance extends Application{

	int minionattack = 0;
	int bossattack = 0;

	public static void main(String[] args) {
	 launch(args); //launches the JavaFX application
}

	Scanner scanschman = new Scanner(System.in);
	 @Override
 	public void start(Stage stage) {

//Music

		final URL resource = getClass().getResource("painstheme.mp3");
    final Media media = new Media(resource.toString());
    final MediaPlayer mediaPlayer = new MediaPlayer(media);
		mediaPlayer.setCycleCount(MediaPlayer.INDEFINITE);
		mediaPlayer.setAutoPlay(true);
    mediaPlayer.play();

 //Swordswoman Battle Scene

    Group root2 = new Group();
    Scene swordbattle = new Scene(root2, 1000, 800);
	  stage.setTitle("Valiance");
	  stage.setScene(swordbattle);

		Rectangle battlewall = new Rectangle(1000, 800);
		root2.getChildren().add(battlewall);
		Image img2 = new Image("file:wall.png");
		ImagePattern pat2 = new ImagePattern(img2);
		battlewall.setFill(pat2);

		sspritebattle BattleSwordswoman = new sspritebattle(20);
		root2.getChildren().add(BattleSwordswoman);
		BattleSwordswoman.setTranslateX(200);
		BattleSwordswoman.setTranslateY(300);

		BossSprite Boss = new BossSprite(20);
		root2.getChildren().add(Boss);
		Boss.setTranslateX(650);
		Boss.setTranslateY(200);

		MinionSprite[] SwordMinion = new MinionSprite[2];

		SwordMinion[0] = new MinionSprite(10);
		SwordMinion[1] = new MinionSprite(10);

		root2.getChildren().add(SwordMinion[0]);
		SwordMinion[0].setTranslateX(800);
		SwordMinion[0].setTranslateY(75); //High = 0, Low = 1

		root2.getChildren().add(SwordMinion[1]);
		SwordMinion[1].setTranslateX(800);
		SwordMinion[1].setTranslateY(600);

	/*	Text SwordMinion1DamageCounter = new Text(50, 50, "-5");
		SwordMinion1DamageCounter.setFont(new Font(20));
		SwordMinion1DamageCounter.setFill(Color.RED);
		//Color.a color is useful because you don't
		//Have to create a new color (with RGB specifics)
		SwordMinion1DamageCounter.setTranslateX(300);
		SwordMinion1DamageCounter.setTranslateY(400);
		SwordMinion1DamageCounter.setFill(new Color (0, 0, 0, 0));
		//SwordMinion1DamageCounter.setVisible(false);
		root2.getChildren().add(SwordMinion1DamageCounter);

		FadeTransition ft = new FadeTransition(Duration.millis(1500), SwordMinion1DamageCounter);
		ft.setFromValue(1.0);
		ft.setToValue(0.1);
		ft.setCycleCount(1);
		ft.setAutoReverse(false); */

		Text instructions = new Text(10, 50, "Select an enemy with 1, 2, or 3 \nand press Enter to perform an attack.");
		instructions.setTranslateX(400);
		instructions.setTranslateY(400);
		instructions.setFill(Color.WHITE);
		root2.getChildren().add(instructions);

		FadeTransition ft2 = new FadeTransition(Duration.millis(7000), instructions); //5000 millis = 5 seconds
		ft2.setFromValue(1.0);
		ft2.setToValue(0.1);
		ft2.setCycleCount(1);
		ft2.setAutoReverse(false);

//HamerGuy Battle Scene

    Group root3 = new Group();
		Scene hguybattle = new Scene(root3, 1000, 800);
	  stage.setTitle("Valiance");
	  stage.setScene(hguybattle);

		Rectangle battlewall2 = new Rectangle(1000, 800);
		root3.getChildren().add(battlewall2);
		Image img3 = new Image("file:wall.png");
		ImagePattern pat3 = new ImagePattern(img3);
		battlewall2.setFill(pat3);

		hguyspritebattle BattleHammerGuy = new hguyspritebattle(20);
		root3.getChildren().add(BattleHammerGuy);
		BattleHammerGuy.setTranslateX(200);
		BattleHammerGuy.setTranslateY(300);

		BossSprite Boss2 = new BossSprite(20);
		root3.getChildren().add(Boss2);
		Boss2.setTranslateX(650);
		Boss2.setTranslateY(200);

		MinionSprite[] HGuyMinion = new MinionSprite[2];

		HGuyMinion[0] = new MinionSprite(10);
		HGuyMinion[1] = new MinionSprite(10);

		root3.getChildren().add(HGuyMinion[0]);
		HGuyMinion[0].setTranslateX(800);
		HGuyMinion[0].setTranslateY(75);

		root3.getChildren().add(HGuyMinion[1]);
		HGuyMinion[1].setTranslateX(800);
		HGuyMinion[1].setTranslateY(600);

		Text instructions2 = new Text(10, 50, "Select an enemy with 1, 2, or 3 \nand press Enter to perform an attack.");
		instructions2.setTranslateX(400);
		instructions2.setTranslateY(400);
		instructions2.setFill(Color.WHITE);
		root3.getChildren().add(instructions2);

		FadeTransition ft3 = new FadeTransition(Duration.millis(7000), instructions2); //5000 millis = 5 seconds
		ft3.setFromValue(1.0);
		ft3.setToValue(0.1);
		ft3.setCycleCount(1);
		ft3.setAutoReverse(false);

//Archer Battle Scene

    Group root4 = new Group();
	  Scene archerbattle = new Scene(root4, 1000, 800);
		stage.setTitle("Valiance");
		stage.setScene(archerbattle);

		Rectangle battlewall4 = new Rectangle(1000, 800);
		root4.getChildren().add(battlewall4);
		Image img4 = new Image("file:wall.png");
		ImagePattern pat4 = new ImagePattern(img4);
		battlewall4.setFill(pat4);

		aspritebattle BattleArcher = new aspritebattle(20);
		root4.getChildren().add(BattleArcher);
		BattleArcher.setTranslateX(200);
		BattleArcher.setTranslateY(300);

		BossSprite Boss3 = new BossSprite(20);
		root4.getChildren().add(Boss3);
		Boss3.setTranslateX(650);
		Boss3.setTranslateY(200);

		MinionSprite[] ArcherMinion = new MinionSprite[2];

		ArcherMinion[0] = new MinionSprite(10);
		ArcherMinion[1] = new MinionSprite(10);

		root4.getChildren().add(ArcherMinion[0]);
		ArcherMinion[0].setTranslateX(800);
		ArcherMinion[0].setTranslateY(75);

		root4.getChildren().add(ArcherMinion[1]);
		ArcherMinion[1].setTranslateX(800);
		ArcherMinion[1].setTranslateY(600); //Reminder: high = 0, low = 1

		Text instructions3 = new Text(10, 50, "Select an enemy with 1, 2, or 3 \nand press Enter to perform an attack.");
		instructions3.setTranslateX(400);
		instructions3.setTranslateY(400);
		instructions3.setFill(Color.WHITE);
		root4.getChildren().add(instructions3);

		FadeTransition ft4 = new FadeTransition(Duration.millis(7000), instructions3);
		ft4.setFromValue(1.0);
		ft4.setToValue(0.1);
		ft4.setCycleCount(1);
		ft4.setAutoReverse(false);

//Healer Battle Scene

    Group root5 = new Group();
	  Scene healerbattle = new Scene(root5, 1000, 800);
		stage.setTitle("Valiance");
		stage.setScene(healerbattle);

		Rectangle battlewall5 = new Rectangle(1000, 800);
		root5.getChildren().add(battlewall5);
		Image img5 = new Image("file:wall.png");
		ImagePattern pat5 = new ImagePattern(img5);
		battlewall5.setFill(pat5);

		hspritebattle BattleHealer = new hspritebattle(20);
		root5.getChildren().add(BattleHealer);
		BattleHealer.setTranslateX(200);
		BattleHealer.setTranslateY(300);

		BossSprite Boss4 = new BossSprite(20);
		root5.getChildren().add(Boss4);
		Boss4.setTranslateX(650);
		Boss4.setTranslateY(200);

		MinionSprite[] HealerMinion = new MinionSprite[2];

		HealerMinion[0] = new MinionSprite(10);
		HealerMinion[1] = new MinionSprite(10);

		root5.getChildren().add(HealerMinion[0]);
		HealerMinion[0].setTranslateX(800);
		HealerMinion[0].setTranslateY(75);

		root5.getChildren().add(HealerMinion[1]);
		HealerMinion[1].setTranslateX(800);
		HealerMinion[1].setTranslateY(600);

		Text instructions4 = new Text(10, 50, "Select an enemy with 1, 2, or 3 \nand press Enter to perform an attack.");
		instructions4.setTranslateX(400);
		instructions4.setTranslateY(400);
		instructions4.setFill(Color.WHITE);
		root5.getChildren().add(instructions4);

		FadeTransition ft5 = new FadeTransition(Duration.millis(7000), instructions4);
		ft5.setFromValue(1.0);
		ft5.setToValue(0.1);
		ft5.setCycleCount(1);
		ft5.setAutoReverse(false);

//Winning Scene

	Group root6 = new Group();
	Scene winningScene = new Scene(root6, 1000, 800);
	stage.setTitle("Valiance");
	stage.setScene(winningScene);

	Text congrats = new Text(10, 50, "Congratulations! Your valiance has saved the kingdom.");
	congrats.setTranslateX(325);
	congrats.setTranslateY(300);

	Text congrats2 = new Text(10, 50, "What quest will you take on next?");
	congrats2.setTranslateX(395);
	congrats2.setTranslateY(425);

	root6.getChildren().add(congrats);
	root6.getChildren().add(congrats2);

//Losing Scene

	Group root7 = new Group();
	Scene losingScene = new Scene(root7, 1000, 800);
	stage.setTitle("Valiance");
	losingScene.setFill(Color.BLACK);
	losingScene.getStylesheets().add("losingScene.css");
	stage.setScene(losingScene);

	Text deathText = new Text(10, 50, "YOU HAVE BEEN VANQUISHED");
	deathText.setId("deathText");
	deathText.setFill(Color.RED);
	deathText.setTranslateX(225);
	deathText.setTranslateY(375);
	deathText.setFont(Font.font(null, FontWeight.BOLD, 80));
	root7.getChildren().add(deathText);

//Opening Scene

    Group root = new Group();
    Scene openingScene = new Scene(root, 1000, 800);
		openingScene.getStylesheets().add("openingtitle.css");
    stage.setTitle("Valiance");
    stage.setScene(openingScene);

		Rectangle wall = new Rectangle(1000, 800);
		root.getChildren().add(wall);
		Image img = new Image("file:wall.png");
		ImagePattern pat = new ImagePattern(img);
		wall.setFill(pat);

		Text title = new Text(10, 50, "Valiance");
		title.setId("opener");
		title.setFont(new Font(20));
		title.setTranslateX(300);
		title.setTranslateY(200);
		root.getChildren().add(title); //Here I was having trouble displaying text.
															//For next time, just remember to NOT forget the root.getChildren().add
															//root.getChildren().add adds whatever you just created onto the scene,
															//Otherwise, it can't be displayed.

		Text desc = new Text(10, 50, "Choose a weapon to start");
		desc.setFont(new Font(20));
		desc.setTranslateX(375);
		desc.setTranslateY(725);
		Color color = new Color(181/255.0, 140/255.0, 27/255.0, 1);
		desc.setFill(color);
		root.getChildren().add(desc);

		//Problem: because javafx runs things from bottom to top (essentially) my DIGIT3 key events are all nullfied byt the fourth DIGIT1
		//Because that DIGIT1 takes precedence. Thus, whenever I click, it will also be a panda. How do I fix that?

		ssprite Swordswoman = new ssprite(new Image("sword.png")); //Before, I thought that I could
																			 	 //store all of the sprites into an array
																				 //But the problem with that is that
																				 //They all have diff. pictures.
																				 //If I made them into an array, I Would
																				 //Have to give them the same image

		Text sworddesc = new Text(10, 50, "Does 5 Damage");
		sworddesc.setId("desc");
		sworddesc.setFont(new Font(20));
		sworddesc.setTranslateX(125);
		sworddesc.setTranslateY(675);
		sworddesc.setFill(color);
		root.getChildren().add(sworddesc);

//Changing the Scene per Weapon Choice

	//Sword

	 EventHandler<MouseEvent> theHandler = new EventHandler<MouseEvent>() {
	 public void handle(MouseEvent event) {
	 			stage.setScene(swordbattle);
				ft2.play();
			 }
	  };
		Swordswoman.setOnMouseClicked(theHandler);

		root.getChildren().add(Swordswoman);
		Swordswoman.setTranslateX(50);
		Swordswoman.setTranslateY(400);

	//Hammer

		hguysprite HammerGuy = new hguysprite(new Image("hammer.png"));

		Text hammerdesc = new Text(10, 50, "Does 5 Damage");
		hammerdesc.setId("desc");
		hammerdesc.setFont(new Font(20));
		hammerdesc.setTranslateX(335);
		hammerdesc.setTranslateY(675);
		hammerdesc.setFill(color);
		root.getChildren().add(hammerdesc);

		EventHandler<MouseEvent> theHandler2 = new EventHandler<MouseEvent>() {
		public void handle(MouseEvent event) {
				 stage.setScene(hguybattle);
				 ft3.play();
				}
		 };

		HammerGuy.setOnMouseClicked(theHandler2);

		root.getChildren().add(HammerGuy);
		HammerGuy.setTranslateX(275);
		HammerGuy.setTranslateY(400);

  //Archer

		asprite Archer = new asprite(new Image("bow.png"));

		Text bowdesc = new Text(10, 50, "Does 5 Damage");
		bowdesc.setId("desc");
		bowdesc.setFont(new Font(20));
		bowdesc.setTranslateX(565);
		bowdesc.setTranslateY(675);
		bowdesc.setFill(color);
		root.getChildren().add(bowdesc);

		EventHandler<MouseEvent> theHandler3 = new EventHandler<MouseEvent>() {
		public void handle(MouseEvent event) {
				 stage.setScene(archerbattle);
				 ft4.play();
				}
		 };
		 Archer.setOnMouseClicked(theHandler3);

		root.getChildren().add(Archer);
		Archer.setTranslateX(525);
		Archer.setTranslateY(400);

	//Healer

		hsprite Healer = new hsprite(new Image("staff.png"));

		Text staffdesc = new Text(5, 25, "Does 2 Damage \n and Heals for 2");
		staffdesc.setId("desc");
		staffdesc.setFont(new Font(20));
		staffdesc.setTranslateX(800);
		staffdesc.setTranslateY(700);
		staffdesc.setFill(color);
		root.getChildren().add(staffdesc);

		EventHandler<MouseEvent> theHandler4 = new EventHandler<MouseEvent>() {
 	 public void handle(MouseEvent event) {
 	 			stage.setScene(healerbattle);
				ft5.play();
 			 }
 	  };
 		Healer.setOnMouseClicked(theHandler4);

		root.getChildren().add(Healer);
		Healer.setTranslateX(750);
		Healer.setTranslateY(400);

    stage.show();

/*

Troubleshooting: So before, whenever I hit ENTER, the damage
Would only affect the LowMinion because that loop
Can before the others. To make up for that, I inputed
Respective letters for 1, 2, and 3 (1 = Q, 2 = W, 3 = E)
I talked to Dr. Kow about that problem and from that
Meeting I was able to find a solution. I used a conditional
Statement analyzing the position of the badguy AND the
ENTER KeyCode. So, if the badguy is selected (shifted
to the left) AND the user presses enter, then that
badguy receives the daamage.
Moral: A little hard work, patience, and effort go
A long way

*/

//Swordswoman Battle

//Reminder: high = 0, low = 1

		EventHandler<KeyEvent> theHandler6 = new EventHandler<KeyEvent>() {
		 public void handle(KeyEvent shattack2) {

		 /*

		 Where it says (KeyEvent ...)
	 	 That is where you're naming the KeyEvent
		 So that if you want to check what specific key was pressed,
		 You would say the name.equals etc.

		  */

		 	//Low Minion Attack

			double x = SwordMinion[1].getTranslateX();

			 if (shattack2.getCode().equals(KeyCode.DIGIT1)){
			 			SwordMinion[1].setTranslateX(790);
						Boss.setTranslateX(650);
						SwordMinion[0].setTranslateX(800);
				}
				if (x == 790 && shattack2.getCode().equals(KeyCode.ENTER)){

					SwordMinion[1].takeDamageFromSwordswoman();
					SwordMinion[1].shinay();
					SwordMinion[1].setTranslateX(800);

					double whichBadGuy = (int)(Math.random() * ((4 - 1)) + 1);

					/*

					 Ran into another problem here. My previous
					randomizer paramater was ((3-1)) and I
					Noticed that if 3 was selected for a typeOfAttack
					The attack wouldn't run through. As I
					Invesitagted, I discovered it was Because
					My randomizer didn't even go up to three
					It went between 0 and 3 and including 3.
					So, to fix that, I had to increase parameter by one
					So that the randomizer would go through all values
					Between 0 and 4, three included. So tip for next time
					Is when you want a specific field of values
					From a randomizer, make sure you always add
					+1 to the range that you want so you can include
					The max that you want.

					*/

						if (SwordMinion[1].shinay() == false){
							if (whichBadGuy == 1 || whichBadGuy == 3){
								System.out.println("The number of Bad Guy is: " + whichBadGuy);
								minionattack = (int)(Math.random() * ((3 - 1)) + 1);
								BattleSwordswoman.takeDamageFromMinion(minionattack);
								BattleSwordswoman.rip();
								BattleSwordswoman.setTranslateX(190);
							}
						else if (whichBadGuy == 2){
							System.out.println("Boss Attack");
							bossattack = (int)(Math.random() * ((4 - 1)) + 1);
							System.out.println("This is the number of boss attack: " + bossattack);
								if (bossattack == 1 || bossattack == 2){
									BattleSwordswoman.takeDamageFromBoss(bossattack);
									BattleSwordswoman.rip();
									BattleSwordswoman.setTranslateX(190);
								}
								else if (bossattack == 3){
									Boss.gainHealth(bossattack);
									System.out.println("Health Increased");
								}
							}
						}
				}

			//Boss Attack

			double y = Boss.getTranslateX();

		 	 if (shattack2.getCode().equals(KeyCode.DIGIT2)){
				 	  Boss.setTranslateX(640);
						SwordMinion[0].setTranslateX(800);
						SwordMinion[1].setTranslateX(800);
				}
				if (y == 640 && shattack2.getCode().equals(KeyCode.ENTER)){
							Boss.takeDamageFromSwordswoman();
							Boss.shinay();
							Boss.setTranslateX(650);

							double whichBadGuy = (int)(Math.random() * ((4 - 1)) + 1);
							if (Boss.shinay() == false){
								if (whichBadGuy == 1 || whichBadGuy == 3){
									System.out.println("The number of Bad Guy is: " + whichBadGuy);
									minionattack = (int)(Math.random() * ((3 - 1)) + 1);
									BattleSwordswoman.takeDamageFromMinion(minionattack);
									BattleSwordswoman.rip();
									BattleSwordswoman.setTranslateX(190);
								}
								else if (whichBadGuy == 2){
									bossattack = (int)(Math.random() * ((4 - 1)) + 1);
									System.out.println("This is the number of boss attack: " + bossattack);
										if (bossattack == 1 || bossattack == 2){
											BattleSwordswoman.takeDamageFromBoss(bossattack);
											BattleSwordswoman.rip();
											BattleSwordswoman.setTranslateX(190);
										}
										else if (bossattack == 3){
											Boss.gainHealth(bossattack);
											System.out.println("Health Increased");
										}
									}
								}

				}

				//High Minion Attack

				double z = SwordMinion[0].getTranslateX();

			 if (shattack2.getCode().equals(KeyCode.DIGIT3)){
				    Boss.setTranslateX(650);
				 		SwordMinion[0].setTranslateX(790);
						SwordMinion[1].setTranslateX(800);
				}
				if (z == 790 && shattack2.getCode().equals(KeyCode.ENTER)){
							SwordMinion[0].takeDamageFromSwordswoman();
							SwordMinion[0].shinay();
							SwordMinion[0].setTranslateX(800);

							double whichBadGuy = (int)(Math.random() * ((4 - 1)) + 1);
							if (SwordMinion[0].shinay() == false){
								if (whichBadGuy == 1 || whichBadGuy == 3){
									System.out.println("The number of Bad Guy is: " + whichBadGuy);
									minionattack = (int)(Math.random() * ((3 - 1)) + 1);
									BattleSwordswoman.takeDamageFromMinion(minionattack);
									BattleSwordswoman.rip();
									BattleSwordswoman.setTranslateX(190);
								}
								else if (whichBadGuy == 2){
									bossattack = (int)(Math.random() * ((4 - 1)) + 1);
									System.out.println("This is the number of boss attack: " + bossattack);
										if (bossattack == 1 || bossattack == 2){
											BattleSwordswoman.takeDamageFromBoss(bossattack);
											BattleSwordswoman.rip();
											BattleSwordswoman.setTranslateX(190);
										}
										else if (bossattack == 3){
											Boss.gainHealth(bossattack);
											System.out.println("Health Increased");
										}
									}
								}
				}

				if (SwordMinion[1].shinay() && SwordMinion[0].shinay() && Boss.shinay()){
					stage.setScene(winningScene);
				}
				else if (BattleSwordswoman.rip()){
					stage.setScene(losingScene);
				}

				/*

				Note for this chunk: So I wanted to, once you won
				or lost the game that a new scene would be
				displayed. At first, I thought I could implement
				this by checking to see if all of the sprites
				had gone to X position 1000 (because that's
				where they "went" if they "died"). That
				didn't really work well so I talked with Dr.
				Moo and he said try using a boolean method instead.
				So, for shinay (in MinionSpirte and BossSprite)
				and rip (in char. sprites) I had both of the
				methods (which were void before) return a boolean.
				It would return true if the sprite moved to X 1000
				and false otherwise. SO, in order to check if
				that happened, all one has to do is call shinay
				and rip because they return true if it works.
				In other words, call SwordMinion[1].shinay()
				and it will return either true or false based on
				the sprites health. Turns out, that works very well
				Moral of the story: Boolean methods may be
				confusing and difficult to wrap one's head
				around, but under guidance and practice, one can
				use them to do really cool things, especially if
				one needs to check if something has occured or not.

				*/

			}
		};
			swordbattle.setOnKeyPressed(theHandler6);

//HammerGuy Battle

EventHandler<KeyEvent> theHandler7 = new EventHandler<KeyEvent>() {
 public void handle(KeyEvent shattack3) {


	//Low Minion Attack

	double x = HGuyMinion[1].getTranslateX();

	 if (shattack3.getCode().equals(KeyCode.DIGIT1)){
				HGuyMinion[1].setTranslateX(790);
				Boss2.setTranslateX(650);
				HGuyMinion[0].setTranslateX(800);
		}
		if (x == 790 && shattack3.getCode().equals(KeyCode.ENTER)){

			HGuyMinion[1].takeDamageFromHammerGuy();
			HGuyMinion[1].shinay();
			HGuyMinion[1].setTranslateX(800);

			double whichBadGuy = (int)(Math.random() * ((4 - 1)) + 1);
			if (HGuyMinion[1].shinay() == false){
				if (whichBadGuy == 1 || whichBadGuy == 3){
					System.out.println("The number of Bad Guy is: " + whichBadGuy);
					minionattack = (int)(Math.random() * ((3 - 1)) + 1);
					BattleHammerGuy.takeDamageFromMinion(minionattack);
					BattleHammerGuy.rip();
				}
				else if (whichBadGuy == 2){
					bossattack = (int)(Math.random() * ((4 - 1)) + 1);
					System.out.println(bossattack);
						if (bossattack == 1 || bossattack == 2){
							System.out.println("This is the number of boss attack: " + bossattack);
							BattleHammerGuy.takeDamageFromBoss(bossattack);
							BattleHammerGuy.rip();
							BattleHammerGuy.setTranslateX(190);
						}
						else if (bossattack == 3){
							Boss2.gainHealth(bossattack);
							System.out.println("Health Increased");
						}
					}
				}
		}

	//Boss Attack

	double y = Boss2.getTranslateX();

	 if (shattack3.getCode().equals(KeyCode.DIGIT2)){
				Boss2.setTranslateX(640);
				HGuyMinion[0].setTranslateX(800);
				HGuyMinion[1].setTranslateX(800);
		}
		if (y == 640 && shattack3.getCode().equals(KeyCode.ENTER)){
					Boss2.takeDamageFromHammerGuy();
					Boss2.shinay();
					Boss2.setTranslateX(650);

					double whichBadGuy = (int)(Math.random() * ((4 - 1)) + 1);
					if (Boss2.shinay() == false){
						if (whichBadGuy == 1 || whichBadGuy == 3){
							System.out.println("The number of Bad Guy is: " + whichBadGuy);
							minionattack = (int)(Math.random() * ((3 - 1)) + 1);
							BattleHammerGuy.takeDamageFromMinion(minionattack);
							BattleHammerGuy.rip();
							BattleHammerGuy.setTranslateX(190);
						}
						else if (whichBadGuy == 2){
							bossattack = (int)(Math.random() * ((4 - 1)) + 1);
							System.out.println("This is the number of boss attack: " + bossattack);
								if (bossattack == 1 || bossattack == 2){
									BattleHammerGuy.takeDamageFromBoss(bossattack);
									BattleHammerGuy.rip();
									BattleHammerGuy.setTranslateX(190);
								}
								else if (bossattack == 3){
									Boss2.gainHealth(bossattack);
									System.out.println("Health Increased");
								}
							}
						}

		}

		//High Minion Attack

		double z = HGuyMinion[0].getTranslateX();

	 if (shattack3.getCode().equals(KeyCode.DIGIT3)){
				Boss2.setTranslateX(650);
				HGuyMinion[0].setTranslateX(790);
				HGuyMinion[1].setTranslateX(800);
		}
		if (z == 790 && shattack3.getCode().equals(KeyCode.ENTER)){
					HGuyMinion[0].takeDamageFromHammerGuy();
					HGuyMinion[0].shinay();
					HGuyMinion[0].setTranslateX(800);

					double whichBadGuy = (int)(Math.random() * ((4 - 1)) + 1);
					if (HGuyMinion[0].shinay() == false){
						if (whichBadGuy == 1 || whichBadGuy == 3){
							System.out.println("The number of Bad Guy is: " + whichBadGuy);
							minionattack = (int)(Math.random() * ((3 - 1)) + 1);
							BattleHammerGuy.takeDamageFromMinion(minionattack);
							BattleHammerGuy.rip();
							BattleHammerGuy.setTranslateX(190);
						}
						else if (whichBadGuy == 2){
							bossattack = (int)(Math.random() * ((4 - 1)) + 1);
							System.out.println("This is the number of boss attack: " + bossattack);
								if (bossattack == 1 || bossattack == 2){
									BattleHammerGuy.takeDamageFromBoss(bossattack);
									BattleHammerGuy.rip();
									BattleHammerGuy.setTranslateX(190);
								}
								else if (bossattack == 3){
									Boss2.gainHealth(bossattack);
									System.out.println("Health Increased");
								}
							}
						}
		}

		if (HGuyMinion[1].shinay() && HGuyMinion[0].shinay() && Boss2.shinay()){
			stage.setScene(winningScene);
		}
		else if (BattleHammerGuy.rip()){
			stage.setScene(losingScene);
		}

	}
};
	hguybattle.setOnKeyPressed(theHandler7);



//Archer Battle

EventHandler<KeyEvent> theHandler8 = new EventHandler<KeyEvent>() {
 public void handle(KeyEvent shattack4) {

	//Low Minion Attack


	double x = ArcherMinion[1].getTranslateX();

	 if (shattack4.getCode().equals(KeyCode.DIGIT1)){
				ArcherMinion[1].setTranslateX(790);
				Boss3.setTranslateX(650);
				ArcherMinion[0].setTranslateX(800);
		}
		if (x == 790 && shattack4.getCode().equals(KeyCode.ENTER)){

			ArcherMinion[1].takeDamageFromArcher();
			ArcherMinion[1].shinay();
			ArcherMinion[1].setTranslateX(800);
					double whichBadGuy = (int)(Math.random() * ((4 - 1)) + 1);
					if (ArcherMinion[1].shinay() == false){
						if (whichBadGuy == 1 || whichBadGuy == 3){
							System.out.println("The number of Bad Guy is: " + whichBadGuy);
							minionattack = (int)(Math.random() * ((3 - 1)) + 1);
							BattleArcher.takeDamageFromMinion(minionattack);
							BattleArcher.rip();
							BattleArcher.setTranslateX(190);
						}
						else if (whichBadGuy == 2){
							bossattack = (int)(Math.random() * ((4 - 1)) + 1);
						System.out.println("This is the number of boss attack: " + bossattack);
								if (bossattack == 1 || bossattack == 2){
									BattleArcher.takeDamageFromBoss(bossattack);
									BattleArcher.rip();
									BattleArcher.setTranslateX(190);
								}
								else if (bossattack == 3){
									Boss3.gainHealth(bossattack);
									System.out.println("Health Increased");
								}
							}
						}
		}

	//Boss Attack

	double y = Boss3.getTranslateX();

	 if (shattack4.getCode().equals(KeyCode.DIGIT2)){
				Boss3.setTranslateX(640);
				ArcherMinion[0].setTranslateX(800);
				ArcherMinion[1].setTranslateX(800);
		}
		if (y == 640 && shattack4.getCode().equals(KeyCode.ENTER)){
					Boss3.takeDamageFromArcher();
					Boss3.shinay();
					Boss3.setTranslateX(650);

						double whichBadGuy = (int)(Math.random() * ((4 - 1)) + 1);
						if (Boss3.shinay() == false){
								if (whichBadGuy == 1 || whichBadGuy == 3){
									System.out.println("The number of Bad Guy is: " + whichBadGuy);
									minionattack = (int)(Math.random() * ((3 - 1)) + 1);
									BattleArcher.takeDamageFromMinion(minionattack);
									BattleArcher.rip();
									BattleArcher.setTranslateX(190);
								}
								else if (whichBadGuy == 2){
									bossattack = (int)(Math.random() * ((4 - 1)) + 1);
									System.out.println("This is the number of boss attack: " + bossattack);
									System.out.println("The number of Bad Guy is: " + whichBadGuy);
										if (bossattack == 1 || bossattack == 2){
											BattleArcher.takeDamageFromBoss(bossattack);
											BattleArcher.rip();
											BattleArcher.setTranslateX(190);
										}
										else if (bossattack == 3){
											Boss3.gainHealth(bossattack);
											System.out.println("Health Increased");
										}
									}
								}
		}

		//High Minion Attack

		double z = ArcherMinion[0].getTranslateX();

	 if (shattack4.getCode().equals(KeyCode.DIGIT3)){
				Boss3.setTranslateX(650);
				ArcherMinion[0].setTranslateX(790);
				ArcherMinion[1].setTranslateX(800);
		}
		if (z == 790 && shattack4.getCode().equals(KeyCode.ENTER)){
					ArcherMinion[0].takeDamageFromArcher();
					ArcherMinion[0].shinay();
					ArcherMinion[0].setTranslateX(800);

						double whichBadGuy = (int)(Math.random() * ((4 - 1)) + 1);
						if (ArcherMinion[0].shinay() == false){
								if (whichBadGuy == 1 || whichBadGuy == 3){
									System.out.println("The number of Bad Guy is: " + whichBadGuy);
									minionattack = (int)(Math.random() * ((3 - 1)) + 1);
									BattleArcher.takeDamageFromMinion(minionattack);
									BattleArcher.rip();
									BattleArcher.setTranslateX(190);
								}
								else if (whichBadGuy == 2){
									bossattack = (int)(Math.random() * ((4 - 1)) + 1);
									System.out.println("This is the number of boss attack: " + bossattack);
										if (bossattack == 1 || bossattack == 2){
											BattleArcher.takeDamageFromBoss(bossattack);
											BattleArcher.rip();
											BattleArcher.setTranslateX(190);
										}
										else if (bossattack == 3){
											Boss3.gainHealth(bossattack);
											System.out.println("Health Increased");
										}
									}
								}
		}

		if (ArcherMinion[1].shinay() && ArcherMinion[0].shinay() && Boss3.shinay()){
			stage.setScene(winningScene);
		}
		else if (BattleArcher.rip()){
			stage.setScene(losingScene);
		}
	}
};
	archerbattle.setOnKeyPressed(theHandler8);



//Healer Battle

EventHandler<KeyEvent> theHandler9 = new EventHandler<KeyEvent>() {
 public void handle(KeyEvent shattack5) {

	//Low Minion Attack

	double x = HealerMinion[1].getTranslateX();

	 if (shattack5.getCode().equals(KeyCode.DIGIT1)){
				HealerMinion[1].setTranslateX(790);
				Boss4.setTranslateX(650);
				HealerMinion[0].setTranslateX(800);
		}
		if (x == 790 && shattack5.getCode().equals(KeyCode.ENTER)){

			HealerMinion[1].takeDamageFromHealer();
			HealerMinion[1].shinay();
			HealerMinion[1].setTranslateX(800);
			BattleHealer.gainHealth();

			double whichBadGuy = (int)(Math.random() * ((4 - 1)) + 1);
			if (HealerMinion[1].shinay() == false){
				if (whichBadGuy == 1 || whichBadGuy == 3){
					System.out.println("The number of Bad Guy is: " + whichBadGuy);
					minionattack = (int)(Math.random() * ((3 - 1)) + 1);
					BattleHealer.takeDamageFromMinion(minionattack);
					BattleHealer.rip();
					BattleHealer.setTranslateX(190);
				}
				else if (whichBadGuy == 2){
					bossattack = (int)(Math.random() * ((4 - 1)) + 1);
					System.out.println("This is the number of boss attack: " + bossattack);
						if (bossattack == 1 || bossattack == 2){
							BattleHealer.takeDamageFromBoss(bossattack);
							BattleHealer.rip();
							BattleHealer.setTranslateX(190);
						}
						else if (bossattack == 3){
							Boss4.gainHealth(bossattack);
							System.out.println("Health Increased");
						}
					}
				}
		}

	//Boss Attack

	double y = Boss4.getTranslateX();

	 if (shattack5.getCode().equals(KeyCode.DIGIT2)){
				Boss4.setTranslateX(640);
				HealerMinion[0].setTranslateX(800);
				HealerMinion[1].setTranslateX(800);
		}
		if (y == 640 && shattack5.getCode().equals(KeyCode.ENTER)){
					Boss4.takeDamageFromHealer();
					Boss4.shinay();
					Boss4.setTranslateX(650);
					BattleHealer.gainHealth();

					double whichBadGuy = (int)(Math.random() * ((4 - 1)) + 1);
					if (Boss4.shinay() == false){
						if (whichBadGuy == 1 || whichBadGuy == 3){
							System.out.println("The number of Bad Guy is: " + whichBadGuy);
							minionattack = (int)(Math.random() * ((3 - 1)) + 1);
							BattleHealer.takeDamageFromMinion(minionattack);
							BattleHealer.rip();
							BattleHealer.setTranslateX(190);
						}
						else if (whichBadGuy == 2){
							bossattack = (int)(Math.random() * ((4 - 1)) + 1);
							System.out.println("This is the number of boss attack: " + bossattack);
								if (bossattack == 1 || bossattack == 2){
									BattleHealer.takeDamageFromBoss(bossattack);
									BattleHealer.rip();
									BattleHealer.setTranslateX(190);
								}
								else if (bossattack == 3){
									Boss4.gainHealth(bossattack);
									System.out.println("Health Increased");
								}
							}
						}

		}

		//High Minion Attack

		double z = HealerMinion[0].getTranslateX();

	 if (shattack5.getCode().equals(KeyCode.DIGIT3)){
				Boss4.setTranslateX(650);
				HealerMinion[0].setTranslateX(790);
				HealerMinion[1].setTranslateX(800);
		}
		if (z == 790 && shattack5.getCode().equals(KeyCode.ENTER)){
					HealerMinion[0].takeDamageFromHealer();
					HealerMinion[0].shinay();
					HealerMinion[0].setTranslateX(800);
					BattleHealer.gainHealth();

					double whichBadGuy = (int)(Math.random() * ((4 - 1)) + 1);
					if (HealerMinion[0].shinay() == false){
						if (whichBadGuy == 1 || whichBadGuy == 3){
							System.out.println("The number of Bad Guy is: " + whichBadGuy);
							minionattack = (int)(Math.random() * ((3 - 1)) + 1);
							BattleHealer.takeDamageFromMinion(minionattack);
							BattleHealer.rip();
							BattleHealer.setTranslateX(190);
						}
						else if (whichBadGuy == 2){
							bossattack = (int)(Math.random() * ((4 - 1)) + 1);
							System.out.println("This is the number of boss attack: " + bossattack);
								if (bossattack == 1 || bossattack == 2){
									BattleHealer.takeDamageFromBoss(bossattack);
									BattleHealer.rip();
									BattleHealer.setTranslateX(190);
								}
								else if (bossattack == 3){
									Boss4.gainHealth(bossattack);
									System.out.println("Health Increased");
								}
							}
						}
		}

		if (HealerMinion[1].shinay() && HealerMinion[0].shinay() && Boss4.shinay()){
			stage.setScene(winningScene);
		}
		else if (BattleHealer.rip()){
			stage.setScene(losingScene);
		}

	}
};
	healerbattle.setOnKeyPressed(theHandler9);
//Same Here

  }
}
