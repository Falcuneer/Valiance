import javafx.application.Application;
import javafx.stage.*;
import javafx.event.*;
import javafx.scene.*;
import javafx.scene.text.*;
import javafx.scene.input.*;
import javafx.scene.shape.*;
import javafx.scene.paint.*;
import javafx.scene.image.*;
import javafx.animation.*;

public class asprite extends Group{

  private ImagePattern imgPattern;
	private Rectangle archersprite;

  public asprite(Image theImage){

    archersprite = new Rectangle(200, 300);

    imgPattern = new ImagePattern(theImage);
    archersprite.setFill(imgPattern);

    this.getChildren().add(archersprite);

  }
}
