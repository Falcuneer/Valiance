import javafx.application.Application;
import javafx.stage.*;
import javafx.event.*;
import javafx.scene.*;
import javafx.scene.text.*;
import javafx.scene.input.*;
import javafx.scene.shape.*;
import javafx.scene.paint.*;
import javafx.scene.image.*;
import javafx.animation.*;

public class aspritebattle extends Group{

  private ImagePattern imgPattern;
	private Rectangle archerbattle;
  private int health;

  public aspritebattle(int h){

    health = h;

    archerbattle = new Rectangle(200, 300);

    Image Archer = new Image("file:archer.png");
    imgPattern = new ImagePattern(Archer);
    archerbattle.setFill(imgPattern);

    this.getChildren().add(archerbattle);
  }

  public void takeDamageFromMinion(double typeOfAttack){
      if(typeOfAttack == 1){
            health = health - 2;
            System.out.println("This is the type of minion attack: " + typeOfAttack);
      }
      else if(typeOfAttack == 2){
          health = health - 3;
          System.out.println("This is the type of minion attack: " + typeOfAttack);
      }
      System.out.println(health);
      }
  public void takeDamageFromBoss(double typeOfAttack){
      if(typeOfAttack == 1){
         health = health - 3;
         System.out.println("This is the type of boss attack: " + typeOfAttack);
       }
      else if(typeOfAttack == 2){
            health = health - 2;
            health = health - 2;
            System.out.println("This is the type of boss attack: " + typeOfAttack);
       }
       System.out.println(health);
      }

      public boolean rip(){
        if(health <= 0){
          archerbattle.setTranslateX(1000);
          return true;
        }
        else {
          return false;
        }
      }
}
