import javafx.application.Application;
import javafx.stage.*;
import javafx.event.*;
import javafx.scene.*;
import javafx.scene.text.*;
import javafx.scene.input.*;
import javafx.scene.shape.*;
import javafx.scene.paint.*;
import javafx.scene.image.*;
import javafx.animation.*;

public class hguysprite extends Group{

  private ImagePattern imgPattern;
	private Rectangle hammersprite;

  public hguysprite(Image theImage){

    hammersprite = new Rectangle(200, 300);

    imgPattern = new ImagePattern(theImage);
    hammersprite.setFill(imgPattern);

    this.getChildren().add(hammersprite);

  }
}
