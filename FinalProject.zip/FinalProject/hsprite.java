import javafx.application.Application;
import javafx.stage.*;
import javafx.event.*;
import javafx.scene.*;
import javafx.scene.text.*;
import javafx.scene.input.*;
import javafx.scene.shape.*;
import javafx.scene.paint.*;
import javafx.scene.image.*;
import javafx.animation.*;

public class hsprite extends Group{

  private ImagePattern imgPattern;
	private Rectangle healersprite;

  public hsprite(Image theImage){

    healersprite = new Rectangle(200, 300);

    imgPattern = new ImagePattern(theImage);
    healersprite.setFill(imgPattern);

    this.getChildren().add(healersprite);

  }
}
