import javafx.application.Application;
import javafx.stage.*;
import javafx.event.*;
import javafx.scene.*;
import javafx.scene.text.*;
import javafx.scene.input.*;
import javafx.scene.shape.*;
import javafx.scene.paint.*;
import javafx.scene.image.*;
import javafx.animation.*;
import java.util.Scanner;

public class hspritebattle extends Group{

  Scanner scanschman = new Scanner(System.in);

  private ImagePattern imgPattern;
	private Rectangle healerbattle;
  private int health;

  public hspritebattle(int h){

    health = h;

    healerbattle = new Rectangle(200, 300);

    Image Healer = new Image("file:healer.png");
    imgPattern = new ImagePattern(Healer);
    healerbattle.setFill(imgPattern);

    this.getChildren().add(healerbattle);
    }

  public void takeDamageFromMinion(double typeOfAttack){
      if(typeOfAttack == 1){
          health = health - 2;
          System.out.println("This is the type of minion attack: " + typeOfAttack);
      }
      else if(typeOfAttack == 2){
          health = health - 3;
          System.out.println("This is the type of minion attack: " + typeOfAttack);
      }
      System.out.println(health);
      }
  public void takeDamageFromBoss(double typeOfAttack){
        if(typeOfAttack == 1){
          health = health - 3;
          System.out.println("This is the type of boss attack: " + typeOfAttack);
         }
         else if(typeOfAttack == 2){
              health = health - 2;
              health = health - 2;
              System.out.println("This is the type of boss attack: " + typeOfAttack);
         }
          System.out.println(health);
        }

    public void gainHealth(){
        health = health + 2;
        System.out.println("Your current health is " + health);
    }
    public boolean rip(){
      if(health <= 0){
        healerbattle.setTranslateX(1000);
        return true;
      }
      else {
        return false;
      }
    }

}
