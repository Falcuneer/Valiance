import javafx.application.Application;
import javafx.stage.*;
import javafx.event.*;
import javafx.scene.*;
import javafx.scene.text.*;
import javafx.scene.input.*;
import javafx.scene.shape.*;
import javafx.scene.paint.*;
import javafx.scene.image.*;
import javafx.animation.*;

public class ssprite extends Group{

  private ImagePattern imgPattern;
	private Rectangle swordsprite;

  public ssprite(Image theImage){

    swordsprite = new Rectangle(230, 330);

    imgPattern = new ImagePattern(theImage);
    swordsprite.setFill(imgPattern);

    this.getChildren().add(swordsprite);
  }
}
