import javafx.application.Application;
import javafx.stage.*;
import javafx.event.*;
import javafx.scene.*;
import javafx.scene.text.*;
import javafx.scene.input.*;
import javafx.scene.shape.*;
import javafx.scene.paint.*;
import javafx.scene.image.*;
import javafx.animation.*;

public class sspritebattle extends Group{

  private ImagePattern imgPattern;
	private Rectangle swordbattle;
  private int health;

  public sspritebattle(int h){

    health = h;

    swordbattle = new Rectangle(200, 300);

    Image Swordswoman = new Image("healer.png");
    imgPattern = new ImagePattern(Swordswoman);
    swordbattle.setFill(imgPattern);

    this.getChildren().add(swordbattle);
  }

  public void takeDamageFromMinion(double typeOfAttack){
      if(typeOfAttack == 1){
          health = health - 2;
          System.out.println("This is the type of minion attack: " + typeOfAttack);
      }
      else if(typeOfAttack == 2){
          health = health - 3;
          System.out.println("This is the type of minion attack: " + typeOfAttack);
      }
      System.out.println(health);
      }
  public void takeDamageFromBoss(double typeOfAttack){
        if(typeOfAttack == 1){
          health = health - 3;
          System.out.println("This is the type of boss attack: " + typeOfAttack);
         }
         else if(typeOfAttack == 2){
              health = health - 2;
              health = health - 2;
              System.out.println("This is the type of boss attack: " + typeOfAttack);
         }
          System.out.println(health);
        }
  public boolean rip(){
    if(health <= 0){
      swordbattle.setTranslateX(1000);
      return true;
    }
    else {
      return false;
    }
  }

}
